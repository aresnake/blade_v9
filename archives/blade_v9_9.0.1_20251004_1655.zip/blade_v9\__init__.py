bl_info = {
    "name": "Blade v9",
    "version": (9, 0, 1),
    "author": "Adrien / ARES",
    9, 0, 2),
    "blender": (4, 5, 0),
    "location": "N-Panel > Blade",
    "description": "Blade v9 Ops quick panel and safe defaults.",
    "category": "3D View"
}

TAG = "[Blade v9]"

import bpy
from bpy.app.handlers import persistent

# Panneau utilitaires (dÃ©clarÃ© dans un module sÃ©parÃ©)
from .ares.ui import extras_v9

def log(msg): print(f"{TAG} {msg}")

# ---------------- Preferences ----------------
class BL9_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__.split(".")[0]
    def draw(self, context):
        self.layout.label(text="Blade v9 Preferences")

# ---------------- Classes Ã  enregistrer ----------------
classes = (BL9_AddonPreferences,)

# ---------------- Init scÃ¨ne (dÃ©fÃ©rÃ©e) ----------------
@persistent
def init_scene_defaults(dummy=None):
    """Initialisation sÃ»re: ne dÃ©pend pas de bpy.context.scene durant register()."""
    try:
        scene = getattr(bpy.context, "scene", None)
        if scene is None:
            if bpy.data.scenes:
                scene = bpy.data.scenes[0]
            else:
                return
        # Exemple de defaults safe (pas d'ops contextuels ici)
        try:
            scene.render.engine = "BLENDER_EEVEE_NEXT"
        except Exception:
            pass
        log("Scene defaults initialized (safe).")
    except Exception as e:
        print(f"{TAG} init_scene_defaults failed: {e}")

def _deferred_scene_init():
    """Timer callback exÃ©cutÃ© aprÃ¨s register() pour disposer d'un contexte valide."""
    try:
        init_scene_defaults()
    except Exception as e:
        print(f"{TAG} deferred init failed: {e}")
    return None  # ne pas replanifier

# ---------------- Register / Unregister ----------------
def register():
    for cls in classes:
        try: bpy.utils.register_class(cls)
        except Exception as e:
            print(f"{TAG} Failed to register {cls.__name__}: {e}")

    # UI Utilitaires
    try:
        extras_v9.register()
        log("extras_v9 registered")
    except Exception as e:
        log(f"extras_v9 register failed: {e}")

    # Hooks diffÃ©rÃ©s: handler + timer (aucun appel direct Ã  init_scene_defaults() ici)
    try:
        if init_scene_defaults not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(init_scene_defaults)
    except Exception as e:
        print(f"{TAG} load_post hook failed: {e}")
    try:
        import bpy.app.timers as _timers
        _timers.register(_deferred_scene_init, first_interval=0.1, persistent=True)
    except Exception as e:
        print(f"{TAG} timer hook failed: {e}")

    log("Add-on registered.")

def unregister():
    # Retirer handler si prÃ©sent
    try:
        if init_scene_defaults in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(init_scene_defaults)
    except Exception:
        pass

    # UI Utilitaires
    try:
        extras_v9.unregister()
        log("extras_v9 unregistered")
    except Exception as e:
        log(f"extras_v9 unregister failed: {e}")

    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except Exception as e:
            print(f"{TAG} Failed to unregister {cls.__name__}: {e}")

    log("Add-on unregistered.")

if __name__ == "__main__":
    register()
